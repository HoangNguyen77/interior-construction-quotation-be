front-end: https://github.com/HoangNguyen77/interior-construction-quotation-fe
