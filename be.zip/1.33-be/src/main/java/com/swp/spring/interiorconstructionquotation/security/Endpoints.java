package com.swp.spring.interiorconstructionquotation.security;

public class Endpoints {
    public static final String front_end_host = "http://localhost:5173";
    public static final String[] PUBLIC_GET_ENDPOINTS = {
        "/users/**"
    };
    public static final String[] PUBLIC_POST_ENDPOINTS = {

    };
    public static final String[] STAFF_GET_ENDPOINTS = {

    };
    public static final String[] STAFF_POST_ENDPOINTS = {

    };
}
