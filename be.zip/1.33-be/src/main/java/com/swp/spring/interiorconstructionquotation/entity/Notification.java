package com.swp.spring.interiorconstructionquotation.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Notification {
    private String content;
}
