package com.swp.spring.interiorconstructionquotation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InteriorConstructionQuotationApplication {

	public static void main(String[] args) {
		SpringApplication.run(InteriorConstructionQuotationApplication.class, args);
	}

}
